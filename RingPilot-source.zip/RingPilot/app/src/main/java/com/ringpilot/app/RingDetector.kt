package com.ringpilot.app

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Lightweight radial vision detector. It looks for a yellow control ring and for a pair
 * of circular edges around it. It intentionally returns low confidence when geometry is
 * ambiguous, so the controller releases rather than blindly pressing on a bad frame.
 */
data class RingObservation(
    val valid: Boolean,
    val controlRadius: Float,
    val innerRadius: Float,
    val outerRadius: Float,
    val confidence: Float,
    val controlConfidence: Float,
    val yellowScore: Float,
    val note: String
) {
    val targetMid get() = (innerRadius + outerRadius) / 2f
    val bandWidth get() = outerRadius - innerRadius
}

class RingDetector {
    private val angles = FloatArray(72) { i ->
        val a = i * 2.0 * Math.PI / 72.0
        a.toFloat()
    }

    fun analyze(
        frame: PixelFrame,
        config: RingConfig,
        previousControlRadius: Float?,
        previousBandCenter: Float?
    ): RingObservation {
        val minDim = min(frame.width, frame.height).toFloat()
        if (minDim < 100f) return invalid("tela pequena")

        val cx = config.centerXPx(frame.width)
        val cy = config.centerYPx(frame.height)
        if (cx !in 5 until frame.width - 5 || cy !in 5 until frame.height - 5) {
            return invalid("centro fora da tela")
        }
        val minR = max(8, (minDim * 0.025f).toInt())
        val maxR = min((minDim * config.scanMaxPercent.coerceIn(8f, 35f) / 100f).toInt(), (minDim * 0.32f).toInt())
        if (maxR <= minR + 15) return invalid("faixa de busca curta")

        val yellow = FloatArray(maxR + 1)
        val edge = FloatArray(maxR + 1)
        val yellowSamples = angles.size.toFloat()
        for (r in minR..maxR) {
            var yellowTotal = 0f
            var edgeTotal = 0f
            for (a in angles) {
                val dx = cos(a)
                val dy = sin(a)
                val px = (cx + r * dx).toInt()
                val py = (cy + r * dy).toInt()
                val rgb = frame.rgb(px, py)
                val red = (rgb shr 16) and 0xff
                val green = (rgb shr 8) and 0xff
                val blue = rgb and 0xff
                if (red > 135 && green > 115 && blue < 165 && red - blue > 45 && green - blue > 30) {
                    yellowTotal += min(1f, min((red - blue) / 125f, (green - blue) / 115f))
                }
                val inside = frame.rgb((cx + (r - 2) * dx).toInt(), (cy + (r - 2) * dy).toInt())
                val outside = frame.rgb((cx + (r + 2) * dx).toInt(), (cy + (r + 2) * dy).toInt())
                var d = 0f
                d += abs(((inside shr 16) and 0xff) - ((outside shr 16) and 0xff))
                d += abs(((inside shr 8) and 0xff) - ((outside shr 8) and 0xff))
                d += abs((inside and 0xff) - (outside and 0xff))
                edgeTotal += d / 765f
            }
            yellow[r] = yellowTotal / yellowSamples
            edge[r] = edgeTotal / angles.size
        }

        val yellowSmoothed = smooth(yellow)
        var bestYellowR = -1
        var bestYellowScore = 0f
        val expectedControl = previousControlRadius ?: minDim * config.initialRadiusPercent.coerceIn(2f, 22f) / 100f
        // If a ring has already been tracked, prefer nearby yellow edges but allow jumps.
        val localRadiusWindow = max(14f, minDim * 0.08f)
        for (r in minR + 2 until maxR - 2) {
            val score = yellowSmoothed[r]
            val nearPrior = abs(r - expectedControl) <= localRadiusWindow
            val adjusted = if (nearPrior) score else score * 0.82f
            if (adjusted > bestYellowScore) {
                bestYellowScore = adjusted
                bestYellowR = r
            }
        }

        val edgeSmoothed = smooth(edge)
        val peaks = ArrayList<EdgePeak>()
        for (r in minR + 3 until maxR - 3) {
            val score = edgeSmoothed[r]
            if (score >= 0.028f && score >= edgeSmoothed[r - 1] && score >= edgeSmoothed[r + 1]) {
                if (peaks.none { abs(it.radius - r) < 4 }) peaks.add(EdgePeak(r.toFloat(), score))
            }
        }
        if (peaks.isEmpty()) return invalid("nenhuma borda circular")

        val controlRadius: Float
        val controlConfidence: Float
        val yellowConfidence = bestYellowScore
        if (bestYellowR > 0 && bestYellowScore >= 0.09f) {
            controlRadius = bestYellowR.toFloat()
            controlConfidence = (bestYellowScore / 0.24f).coerceIn(0f, 1f)
        } else {
            val fallbackPeak = peaks.minByOrNull { abs(it.radius - expectedControl) }
            if (fallbackPeak == null || abs(fallbackPeak.radius - expectedControl) > localRadiusWindow) {
                return invalid("anel de controle não identificado")
            }
            controlRadius = fallbackPeak.radius
            controlConfidence = (fallbackPeak.strength / 0.14f).coerceIn(0f, 0.52f)
        }

        val preferredBandCenter = previousBandCenter ?: controlRadius
        var bestPair: PairCandidate? = null
        for (i in peaks.indices) {
            for (j in i + 1 until peaks.size) {
                val inner = peaks[i]
                val outer = peaks[j]
                if (outer.radius <= inner.radius) continue
                val separation = outer.radius - inner.radius
                if (separation < max(9f, minDim * 0.016f) || separation > minDim * 0.12f) continue
                val mid = (inner.radius + outer.radius) / 2f
                val proximity = (1f - abs(mid - preferredBandCenter) / (minDim * 0.105f)).coerceIn(0f, 1f)
                val controlProximity = (1f - abs(mid - controlRadius) / (minDim * 0.15f)).coerceIn(0f, 1f)
                val edgeQuality = ((inner.strength + outer.strength) / 2f / 0.18f).coerceIn(0f, 1f)
                val idealWidth = minDim * 0.055f
                val widthQuality = (1f - abs(separation - idealWidth) / (minDim * 0.075f)).coerceIn(0f, 1f)
                val score = 0.41f * edgeQuality + 0.42f * proximity + 0.05f * controlProximity + 0.12f * widthQuality
                if (bestPair == null || score > bestPair!!.score) {
                    bestPair = PairCandidate(inner.radius, outer.radius, score)
                }
            }
        }

        val pair = bestPair ?: return RingObservation(
            valid = false, controlRadius = controlRadius, innerRadius = 0f, outerRadius = 0f,
            confidence = 0f, controlConfidence = controlConfidence, yellowScore = yellowConfidence,
            note = "borda do alvo ambígua"
        )
        val totalConfidence = (pair.score * min(1f, controlConfidence / 0.42f)).coerceIn(0f, 1f)
        val valid = pair.score >= 0.34f && controlConfidence >= 0.12f && pair.outer > pair.inner
        return RingObservation(
            valid = valid,
            controlRadius = controlRadius,
            innerRadius = pair.inner,
            outerRadius = pair.outer,
            confidence = totalConfidence,
            controlConfidence = controlConfidence,
            yellowScore = yellowConfidence,
            note = if (valid) "anel detectado" else "confiança insuficiente"
        )
    }

    private data class EdgePeak(val radius: Float, val strength: Float)
    private data class PairCandidate(val inner: Float, val outer: Float, val score: Float)

    private fun smooth(input: FloatArray): FloatArray {
        val out = input.copyOf()
        for (i in 1 until input.size - 1) out[i] = (input[i - 1] + input[i] * 2f + input[i + 1]) / 4f
        return out
    }

    private fun invalid(message: String) = RingObservation(
        valid = false, controlRadius = 0f, innerRadius = 0f, outerRadius = 0f,
        confidence = 0f, controlConfidence = 0f, yellowScore = 0f, note = message
    )
}
