package com.ringpilot.app

import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val requestCapture = 401
    private lateinit var centerXField: EditText
    private lateinit var centerYField: EditText
    private lateinit var buttonXField: EditText
    private lateinit var buttonYField: EditText
    private lateinit var initialRadiusField: EditText
    private lateinit var scanMaxField: EditText
    private lateinit var toleranceField: EditText
    private lateinit var invertCheck: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xff102033.toInt()
        window.navigationBarColor = 0xff102033.toInt()
        buildLayout()
        loadFields()
    }

    private fun buildLayout() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(10))
            setBackgroundColor(0xffeef2f6.toInt())
        }
        val title = TextView(this).apply {
            text = "RingPilot — estabilizador visual"
            textSize = 24f
            setTextColor(0xff102033.toInt())
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title)
        val intro = TextView(this).apply {
            text = "O app captura a tela do aparelho, estima o raio do anel e envia toques por Acessibilidade. Os valores iniciais são aproximados a partir dos vídeos; calibre antes de confiar no controle."
            textSize = 14f
            setTextColor(0xff35465b.toInt())
            setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(intro)

        val scroll = ScrollView(this)
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(2), 0, dp(8))
        }
        centerXField = addField(form, "Centro do conjunto circular — X (% da largura)", "54")
        centerYField = addField(form, "Centro do conjunto circular — Y (% da altura)", "52")
        buttonXField = addField(form, "Botão de controle — X (% da largura)", "6")
        buttonYField = addField(form, "Botão de controle — Y (% da altura)", "53")
        initialRadiusField = addField(form, "Raio inicial estimado do anel (%)", "7")
        scanMaxField = addField(form, "Raio máximo analisado (%)", "21")
        toleranceField = addField(form, "Tolerância dentro da faixa-alvo (%)", "8")
        invertCheck = CheckBox(this).apply {
            text = "Inverter ação (segurar quando o anel estiver grande)"
            textSize = 14f
            setTextColor(0xff182a3e.toInt())
        }
        form.addView(invertCheck)
        val help = TextView(this).apply {
            text = "Padrão: segurar o botão faz o anel crescer; soltar permite diminuir. Ative ‘Inverter ação’ se o comportamento real for o contrário. X/Y são percentuais da tela em paisagem. O controlador só age quando a detecção tem confiança suficiente."
            textSize = 13f
            setTextColor(0xff536273.toInt())
            setPadding(0, dp(4), 0, dp(8))
        }
        form.addView(help)
        val accessibility = Button(this).apply {
            text = "1. Ativar serviço de Acessibilidade"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        form.addView(accessibility)
        val overlay = Button(this).apply {
            text = "2. Permitir sobreposição na tela"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                }
            }
        }
        form.addView(overlay)
        val start = Button(this).apply {
            text = "3. Salvar e iniciar análise"
            setOnClickListener { saveAndRequestStart() }
        }
        form.addView(start)
        val disclaimer = TextView(this).apply {
            text = "Limite realista: não é possível prometer 99% usando apenas estes vídeos. A mudança de raio, a resposta do jogo, a cor do anel e o ponto de toque precisam ser validados no aparelho. O app pausa a ação quando não consegue identificar os círculos com confiança."
            textSize = 13f
            setTextColor(0xff8a2c2c.toInt())
            setPadding(0, dp(8), 0, dp(4))
        }
        form.addView(disclaimer)
        scroll.addView(form)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun addField(parent: LinearLayout, label: String, default: String): EditText {
        val text = TextView(this).apply {
            this.text = label
            textSize = 13f
            setTextColor(0xff26374a.toInt())
            setPadding(0, dp(3), 0, 0)
        }
        parent.addView(text)
        val field = EditText(this).apply {
            setText(default)
            textSize = 15f
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            singleLine = true
            setPadding(dp(10), 0, dp(10), 0)
            setBackgroundColor(0xffffffff.toInt())
        }
        parent.addView(field, LinearLayout.LayoutParams(dp(220), dp(40)))
        return field
    }

    private fun loadFields() {
        val c = RingConfig.load(this)
        centerXField.setText(c.centerX.toString())
        centerYField.setText(c.centerY.toString())
        buttonXField.setText(c.buttonX.toString())
        buttonYField.setText(c.buttonY.toString())
        initialRadiusField.setText(c.initialRadiusPercent.toString())
        scanMaxField.setText(c.scanMaxPercent.toString())
        toleranceField.setText(c.tolerancePercent.toString())
        invertCheck.isChecked = c.invertHoldDirection
    }

    private fun saveAndRequestStart() {
        val c = RingConfig(
            centerX = read(centerXField, 54f).coerceIn(0f, 100f),
            centerY = read(centerYField, 52f).coerceIn(0f, 100f),
            buttonX = read(buttonXField, 6f).coerceIn(0f, 100f),
            buttonY = read(buttonYField, 53f).coerceIn(0f, 100f),
            initialRadiusPercent = read(initialRadiusField, 7f).coerceIn(2f, 22f),
            scanMaxPercent = read(scanMaxField, 21f).coerceIn(8f, 35f),
            tolerancePercent = read(toleranceField, 8f).coerceIn(1f, 30f),
            invertHoldDirection = invertCheck.isChecked
        )
        RingConfig.save(this, c)

        if (!isAccessibilityEnabled(this)) {
            Toast.makeText(this, "Ative o RingPilot na lista de acessibilidade e toque em iniciar novamente.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permita a sobreposição e toque em iniciar novamente.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
    }

    @Deprecated("Kept compatible with the project's min SDK and simple permission flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestCapture) return
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, "Captura de tela não autorizada.", Toast.LENGTH_SHORT).show()
            return
        }
        val service = Intent(this, RingMonitorService::class.java).apply {
            putExtra(RingMonitorService.EXTRA_RESULT_CODE, resultCode)
            putExtra(RingMonitorService.EXTRA_PROJECTION_DATA, data)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service) else startService(service)
        Toast.makeText(this, "Análise iniciada. Volte para o jogo; use o painel flutuante para pausar.", Toast.LENGTH_LONG).show()
    }

    private fun read(field: EditText, fallback: Float): Float = field.text.toString().trim().replace(',', '.').toFloatOrNull() ?: fallback
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        fun isAccessibilityEnabled(context: Context): Boolean {
            val expected = ComponentName(context, RingAccessibilityService::class.java).flattenToString()
            val enabled = Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
            return enabled.split(':').any { it.equals(expected, ignoreCase = true) }
        }
    }
}
