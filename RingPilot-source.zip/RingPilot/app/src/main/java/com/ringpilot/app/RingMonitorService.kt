package com.ringpilot.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class RingMonitorService : Service() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var workerThread: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: android.hardware.display.VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var windowManager: WindowManager? = null
    private var overlay: View? = null
    private var statusText: TextView? = null
    private var pauseButton: Button? = null
    @Volatile private var paused = false
    private var lastProcessAt = 0L
    @Volatile private var lastScreenWidth = 1280
    @Volatile private var lastScreenHeight = 720
    private var validFrames = 0
    private var previousControlRadius: Float? = null
    private var previousBandCenter: Float? = null
    private var lastControlState: Boolean? = null
    private val detector = RingDetector()
    private lateinit var config: RingConfig

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        config = RingConfig.load(this)
        createNotificationChannel()
        startForegroundCompat()
        workerThread = HandlerThread("RingPilotVision").also { it.start() }
        workerHandler = Handler(workerThread!!.looper)
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (projection != null) return START_STICKY
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_PROJECTION_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_PROJECTION_DATA)
        }
        if (resultCode == 0 || data == null) {
            updateStatus("Captura não autorizada. Pare e inicie novamente.")
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { mainHandler.post { stopSelf() } }
            }, mainHandler)
            beginCapture()
        } catch (e: Exception) {
            updateStatus("Falha ao iniciar captura: ${e.javaClass.simpleName}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun beginCapture() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader!!.setOnImageAvailableListener({ reader -> processImage(reader) }, workerHandler)
        virtualDisplay = projection?.createVirtualDisplay(
            "RingPilotDisplay", width, height, density,
            android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader!!.surface, null, workerHandler
        )
        updateStatus("Captura ativa • abra o mini game")
    }

    private fun processImage(reader: ImageReader) {
        val image = try { reader.acquireLatestImage() } catch (_: Exception) { null } ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastProcessAt < 100L) return
            lastProcessAt = now
            val plane = image.planes[0]
            val buffer = plane.buffer
            val bytes = ByteArray(buffer.remaining())
            buffer.get(bytes)
            val frame = PixelFrame(bytes, image.width, image.height, plane.rowStride, plane.pixelStride)
            lastScreenWidth = image.width
            lastScreenHeight = image.height
            if (paused) {
                releaseControl()
                postStatus("PAUSADO • análise visual ativa")
                return
            }

            val observation = detector.analyze(frame, config, previousControlRadius, previousBandCenter)
            if (observation.valid) {
                validFrames++
                previousControlRadius = observation.controlRadius
                previousBandCenter = observation.targetMid
                val error = observation.targetMid - observation.controlRadius
                val deadband = max(2.0f, observation.bandWidth * config.tolerancePercent / 100f)
                val enoughFrames = validFrames >= 2 || observation.confidence >= 0.70f
                if (observation.confidence >= 0.22f && observation.controlConfidence >= 0.12f && enoughFrames) {
                    val shouldGrow = error > deadband
                    val shouldShrink = error < -deadband
                    val holdWanted = when {
                        shouldGrow -> !config.invertHoldDirection
                        shouldShrink -> config.invertHoldDirection
                        else -> false
                    }
                    sendControl(holdWanted, frame.width, frame.height)
                    val action = if (holdWanted) "SEGURAR" else if (abs(error) <= deadband) "CENTRO" else "SOLTAR"
                    postStatus(String.format(
                        Locale.US,
                        "%s • R %.0f • alvo %.0f–%.0f • erro %+.1f • conf %.0f%%",
                        action, observation.controlRadius, observation.innerRadius, observation.outerRadius,
                        error, observation.confidence * 100f
                    ))
                } else {
                    releaseControl()
                    postStatus(String.format(Locale.US, "CALIBRANDO • conf %.0f%% • %s", observation.confidence * 100f, observation.note))
                }
            } else {
                validFrames = 0
                releaseControl()
                postStatus("Aguardando círculos • ${observation.note}")
            }
        } catch (e: Exception) {
            releaseControl()
            postStatus("Erro de análise: ${e.javaClass.simpleName}")
        } finally {
            image.close()
        }
    }

    private fun sendControl(hold: Boolean, width: Int, height: Int) {
        if (lastControlState == hold) return
        lastControlState = hold
        val x = config.buttonXPx(width)
        val y = config.buttonYPx(height)
        RingAccessibilityService.instance?.setHold(hold, x, y)
        if (RingAccessibilityService.instance == null) postStatus("Ative o serviço de Acessibilidade")
    }

    private fun releaseControl() {
        if (lastControlState != false) {
            lastControlState = false
            RingAccessibilityService.instance?.setHold(false, config.buttonXPx(lastScreenWidth), config.buttonYPx(lastScreenHeight))
        }
    }

    private fun showOverlay() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(0xee102033.toInt())
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), 0xff59d5c6.toInt())
            }
        }
        statusText = TextView(this).apply {
            text = "RingPilot iniciando…"
            textSize = 12f
            setTextColor(0xffffffff.toInt())
            maxLines = 3
        }
        panel.addView(statusText)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        pauseButton = Button(this).apply {
            text = "Pausar"
            textSize = 11f
            minHeight = dp(38)
            setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener {
                paused = !paused
                text = if (paused) "Retomar" else "Pausar"
                if (paused) releaseControl()
                updateStatus(if (paused) "PAUSADO" else "Retomado")
            }
        }
        val stopButton = Button(this).apply {
            text = "Parar"
            textSize = 11f
            minHeight = dp(38)
            setPadding(dp(4), 0, dp(4), 0)
            setOnClickListener { stopSelf() }
        }
        row.addView(pauseButton, LinearLayout.LayoutParams(0, dp(38), 1f))
        row.addView(stopButton, LinearLayout.LayoutParams(0, dp(38), 1f))
        panel.addView(row)
        @Suppress("DEPRECATION")
        val windowType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            dp(280), WindowManager.LayoutParams.WRAP_CONTENT,
            windowType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(36)
        }
        try {
            windowManager?.addView(panel, params)
            overlay = panel
        } catch (_: Exception) {
            // The user can still stop the service from Android's notification shade.
        }
    }

    private fun postStatus(message: String) {
        mainHandler.post { updateStatus(message) }
    }

    private fun updateStatus(message: String) {
        statusText?.text = message
    }

    private fun startForegroundCompat() {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )
        val notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("RingPilot ativo")
                .setContentText("Analisando os círculos do mini game")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(openIntent)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("RingPilot ativo")
                .setContentText("Analisando os círculos do mini game")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentIntent(openIntent)
                .setOngoing(true)
                .build()
        }
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIFICATION_ID, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "RingPilot", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() {
        paused = true
        releaseControl()
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) { }
        overlay = null
        try { virtualDisplay?.release() } catch (_: Exception) { }
        virtualDisplay = null
        try { imageReader?.setOnImageAvailableListener(null, null); imageReader?.close() } catch (_: Exception) { }
        imageReader = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        workerThread?.quitSafely()
        workerThread = null
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_PROJECTION_DATA = "projection_data"
        private const val CHANNEL_ID = "ringpilot_capture"
        private const val NOTIFICATION_ID = 7314
    }
}
