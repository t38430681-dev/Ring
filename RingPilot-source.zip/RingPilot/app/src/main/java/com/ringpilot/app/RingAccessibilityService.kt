package com.ringpilot.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/** Sends calibrated press-and-hold gestures to the selected in-game control. */
class RingAccessibilityService : AccessibilityService() {
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var wantsHold = false
    private var holdGestureRunning = false
    private var activeX = 0
    private var activeY = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() { setHold(false, activeX, activeY) }

    fun setHold(hold: Boolean, x: Int, y: Int) {
        mainHandler.post {
            activeX = x.coerceAtLeast(1)
            activeY = y.coerceAtLeast(1)
            val wasHolding = wantsHold
            wantsHold = hold
            if (hold && !holdGestureRunning) dispatchHold()
            if (!hold && wasHolding && holdGestureRunning) dispatchReleaseTap()
        }
    }

    private fun dispatchHold() {
        if (!wantsHold) return
        val path = Path().apply {
            moveTo(activeX.toFloat(), activeY.toFloat())
            lineTo(activeX + 0.5f, activeY + 0.5f)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0, 9_000)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        holdGestureRunning = true
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                holdGestureRunning = false
                if (wantsHold) mainHandler.postDelayed({ dispatchHold() }, 8)
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                holdGestureRunning = false
                if (wantsHold) mainHandler.postDelayed({ dispatchHold() }, 15)
            }
        }, mainHandler)
        if (!accepted) holdGestureRunning = false
    }

    /** A short stroke cancels the long stroke and leaves the game button released. */
    private fun dispatchReleaseTap() {
        val x = activeX
        val y = activeY
        val path = Path().apply {
            moveTo(x.toFloat(), y.toFloat())
            lineTo((x + 1).toFloat(), (y + 1).toFloat())
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 35))
            .build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { holdGestureRunning = false }
            override fun onCancelled(gestureDescription: GestureDescription?) { holdGestureRunning = false }
        }, mainHandler)
        holdGestureRunning = false
    }

    override fun onDestroy() {
        wantsHold = false
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: RingAccessibilityService? = null
            private set
    }
}
