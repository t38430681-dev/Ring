package com.ringpilot.app

import android.content.Context
import android.content.SharedPreferences

/** Screen positions are percentages so they survive different landscape resolutions. */
data class RingConfig(
    val centerX: Float = 54f,
    val centerY: Float = 52f,
    val buttonX: Float = 6f,
    val buttonY: Float = 53f,
    val initialRadiusPercent: Float = 7f,
    val scanMaxPercent: Float = 21f,
    val tolerancePercent: Float = 8f,
    val invertHoldDirection: Boolean = false
) {
    fun centerXPx(width: Int) = (centerX.coerceIn(0f, 100f) / 100f * width).toInt()
    fun centerYPx(height: Int) = (centerY.coerceIn(0f, 100f) / 100f * height).toInt()
    fun buttonXPx(width: Int) = (buttonX.coerceIn(0f, 100f) / 100f * width).toInt()
    fun buttonYPx(height: Int) = (buttonY.coerceIn(0f, 100f) / 100f * height).toInt()

    companion object {
        private const val PREFS = "ringpilot_settings"

        fun load(context: Context): RingConfig {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            return RingConfig(
                centerX = p.getFloat("centerX", 54f),
                centerY = p.getFloat("centerY", 52f),
                buttonX = p.getFloat("buttonX", 6f),
                buttonY = p.getFloat("buttonY", 53f),
                initialRadiusPercent = p.getFloat("initialRadiusPercent", 7f),
                scanMaxPercent = p.getFloat("scanMaxPercent", 21f),
                tolerancePercent = p.getFloat("tolerancePercent", 8f),
                invertHoldDirection = p.getBoolean("invertHoldDirection", false)
            )
        }

        fun save(context: Context, config: RingConfig) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putFloat("centerX", config.centerX)
                .putFloat("centerY", config.centerY)
                .putFloat("buttonX", config.buttonX)
                .putFloat("buttonY", config.buttonY)
                .putFloat("initialRadiusPercent", config.initialRadiusPercent)
                .putFloat("scanMaxPercent", config.scanMaxPercent)
                .putFloat("tolerancePercent", config.tolerancePercent)
                .putBoolean("invertHoldDirection", config.invertHoldDirection)
                .apply()
        }
    }
}

/** A frame backed by MediaProjection's RGBA_8888 plane. */
data class PixelFrame(
    val bytes: ByteArray,
    val width: Int,
    val height: Int,
    val rowStride: Int,
    val pixelStride: Int
) {
    fun rgb(xRaw: Int, yRaw: Int): Int {
        val x = xRaw.coerceIn(0, width - 1)
        val y = yRaw.coerceIn(0, height - 1)
        val offset = y * rowStride + x * pixelStride
        if (offset < 0 || offset + 2 >= bytes.size) return 0xff000000.toInt()
        val r = bytes[offset].toInt() and 0xff
        val g = bytes[offset + 1].toInt() and 0xff
        val b = bytes[offset + 2].toInt() and 0xff
        return (0xff shl 24) or (r shl 16) or (g shl 8) or b
    }
}
