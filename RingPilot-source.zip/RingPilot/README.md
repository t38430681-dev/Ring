# RingPilot — controle visual experimental para mini game circular

Projeto Android em Kotlin que observa a tela do aparelho e tenta manter o anel controlado no centro da faixa circular-alvo. Não depende de servidor nem envia imagens para a internet; a análise é feita localmente.

## O que foi observado nos vídeos fornecidos

- Os três clipes têm cerca de 35–36 segundos. Dois mostram a mesma cena em resoluções diferentes; o terceiro tem outro enquadramento.
- O conjunto de círculos fica aproximadamente no centro da área de jogo. A imagem enviada foi filmada de um ângulo, então as posições vistas no vídeo não são coordenadas exatas da tela do aparelho.
- Os contornos claros/rosados e o diâmetro aparente da área circular mudam ao longo da tentativa; em alguns momentos, aparecem contornos amarelos. A mudança de estado pode ocorrer rapidamente.
- Há telas “FAILED” aproximadamente em 12 s em dois trechos. Isso prova que as tentativas mostradas falharam, mas não permite calcular a precisão ideal nem descobrir com segurança a relação entre cada toque e o movimento do anel.
- A interface mostra um botão grande à esquerda. O projeto usa como ponto inicial aproximado X=6%, Y=53% e centro circular X=54%, Y=52%, relativos à tela em paisagem. Esses valores precisam ser ajustados no aparelho.

## Como o algoritmo funciona

1. Usa `MediaProjection` para capturar diretamente a tela do aparelho, em vez de processar o vídeo filmado de fora.
2. Analisa amostras radiais ao redor do centro configurado. Mede mudanças de cor/intensidade para localizar bordas circulares e procura uma borda de controle amarela quando a cor está suficientemente presente.
3. Estima duas bordas da faixa-alvo e seu ponto médio em cada quadro. A faixa é recalculada continuamente para reagir a mudanças repentinas, sem suavizar grandes mudanças por vários segundos.
4. Compara o raio observado ao ponto médio da faixa. No modo inicial, segura o botão calibrado para aumentar o anel e solta para permitir que diminua. A opção **Inverter ação** troca essa hipótese.
5. Usa uma zona de tolerância e exige confiança mínima. Se a leitura ficar ambígua, solta o botão em vez de continuar atuando cegamente.

A detecção é heurística, não um modelo treinado. Os círculos podem ter cores/contornos diferentes, e personagens, textos ou outros elementos podem interferir na análise. A qualidade do detector e o sentido real do botão devem ser validados no jogo.

## Instalação e uso

1. Envie a pasta do projeto para um repositório GitHub.
2. Abra **Actions** e execute o workflow **RingPilot Android Build** (ou faça um `push`).
3. Baixe o artefato `RingPilot-debug-apk` e instale `app-debug.apk` no Android. É necessário Android 8.0/API 26 ou superior.
4. Abra o RingPilot e habilite **Acessibilidade** para RingPilot e a permissão de **sobreposição**.
5. Ajuste centro e botão usando percentuais da tela em paisagem. Salve e toque em **iniciar análise**, autorizando a captura da tela.
6. Volte ao mini game. O painel flutuante mostra raio, faixa, erro e confiança; use **Pausar** imediatamente se tocar no controle estiver fazendo algo inesperado.

O ponto padrão de toque é aproximado e pode precisar de calibração. Se segurar o botão fizer o anel diminuir, marque **Inverter ação**. Se o jogo usar toques breves em vez de segurar/soltar, a lógica de atuação terá de ser adaptada para esse mecanismo.

## Limitações honestas

- Não é possível prometer 99% com os clipes atuais: eles não mostram os dados internos do mini game nem dão a resposta exata do jogo a cada toque.
- Este repositório é uma primeira versão experimental; não foi validado neste ambiente em um aparelho Android real. O workflow do GitHub é fornecido para compilar o APK.
- A captura e os gestos dependem das permissões Android. Alguns jogos podem bloquear sobreposições ou entrada por Acessibilidade.
- Ajustar o centro, o ponto de toque e a hipótese de controle pode ser necessário para cada aparelho/resolução/versão do jogo.

## Estrutura

- `app/src/main/java/com/ringpilot/app/MainActivity.kt`: tela de configuração e permissões.
- `RingMonitorService.kt`: captura em tempo real, painel flutuante e controlador.
- `RingDetector.kt`: análise radial dos círculos.
- `RingAccessibilityService.kt`: envio de gestos.
- `.github/workflows/android-build.yml`: build automático do APK no GitHub Actions.
- `Build.yml`: cópia do workflow solicitada para o repositório; o GitHub só executa workflows dentro de `.github/workflows/`.
