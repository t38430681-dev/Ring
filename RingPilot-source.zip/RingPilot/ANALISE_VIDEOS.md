# Notas de inspeção dos clipes

| Arquivo | Duração aproximada | Resolução | Observação útil |
|---|---:|---:|---|
| `1000411404.mp4` | 35,35 s | 1280×576 | Cena/framing diferente; contornos concêntricos mudam de tamanho/contraste durante a sequência. |
| `1000411444.mp4` | 36,13 s | 960×540 | Cena muito parecida com o clipe 1449; tela “FAILED” aparece perto de 12 s e no final do trecho. |
| `1000411449.mp4` | 35,50 s | 1280×720 | Círculos no centro da área de jogo; tela “FAILED” aparece perto de 12 s. |

## Consequências para a implementação

- Não usar coordenadas fixas em pixels; o app usa percentuais para sobreviver a resoluções diferentes.
- Não usar o vídeo filmado como fonte de controle: a perspectiva de câmera distorce círculos. A aplicação analisa uma captura da própria tela.
- Recalcular o raio e a faixa-alvo a cada quadro útil, aceitando alterações grandes em vez de depender exclusivamente de uma média lenta.
- Usar confiança e tolerância: o sistema deixa de atuar quando não consegue separar com segurança as bordas.
- Tratar o botão como uma hipótese configurável. Os vídeos não provam se o botão deve ser segurado, tocado rapidamente ou se a ação deve ser invertida.

## O que falta medir para chegar perto de 99%

1. Capturar gravações digitais da tela (não filmagens de outro aparelho) junto com o histórico dos toques enviados.
2. Identificar, em quadros rotulados, qual contorno é o anel controlado e quais dois contornos formam a faixa-alvo.
3. Medir latência, velocidade de crescimento/decrescimento e tamanho dos saltos após cada estabilização.
4. Rodar dezenas de tentativas, medir a fração de tempo dentro da tolerância e ajustar o controlador com os resultados. Sem esses dados, “99%” é uma meta, não um resultado demonstrado.
